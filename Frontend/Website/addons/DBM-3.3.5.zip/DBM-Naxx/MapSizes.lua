DBM:RegisterMapSize("Naxxramas",
	1, 1093.83007813, 729.2199707,		-- The Construct Quarter
	2, 1093.83007813, 729.2199707,		-- The Arachnid Quarter
	3, 1200, 800,						-- The Military Quarter
	4, 1200.33007813, 800.2199707,		-- The Plague Quarter
	5, 2069.80981445, 1379.87988281,	-- The Lower Necropolis
	6, 655.9399414, 437.29003906		-- The Upper Necropolis
)
