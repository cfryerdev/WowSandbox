DBM:RegisterMapSize("Nexus80",
	1, 514.706970217, 343.138977053,	-- Band of Variance
	2, 664.706970217, 443.138977053,	-- Band of Acceleration
	3, 514.706970217, 343.138977053,	-- Band of Transmutation
	4, 294.700988772, 196.463989261		-- Band of Alignment
)
